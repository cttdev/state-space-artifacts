var classfrc_1_1_error =
[
    [ "Code", "classfrc_1_1_error.html#a86148bf5e8aca24b02c5bb6ae13cd9d1", null ],
    [ "Error", "classfrc_1_1_error.html#aade3bb21dcbc9eb726bf2b13eda42dc4", null ],
    [ "Error", "classfrc_1_1_error.html#af8f28bdee1081edd1db46f0e50cfc600", null ],
    [ "Clear", "classfrc_1_1_error.html#aac7633b1fc3bee0e4baffe82559d6117", null ],
    [ "GetCode", "classfrc_1_1_error.html#a56bf8d2cdf5fa5a45342a3a4d084bbaf", null ],
    [ "GetFilename", "classfrc_1_1_error.html#a8435e67158b657997b1e8da7a77fa58f", null ],
    [ "GetFunction", "classfrc_1_1_error.html#a16aa7ff64537cae21842db97326f0f71", null ],
    [ "GetLineNumber", "classfrc_1_1_error.html#a3811cb47e1c661e6c8600648832cbf0e", null ],
    [ "GetMessage", "classfrc_1_1_error.html#ad505ac3e68ddd7d8e8f14444c078f803", null ],
    [ "GetOriginatingObject", "classfrc_1_1_error.html#a99ab9707eafd09e1bca6259bb62e26a9", null ],
    [ "GetTimestamp", "classfrc_1_1_error.html#abeb01f3a41b2e196d1c1404dc303b3f5", null ],
    [ "operator<", "classfrc_1_1_error.html#aa6fe79cd716075f3f51322448225d1f9", null ],
    [ "Set", "classfrc_1_1_error.html#a49e60d66ddd51cca0903a87f1e5e1443", null ]
];
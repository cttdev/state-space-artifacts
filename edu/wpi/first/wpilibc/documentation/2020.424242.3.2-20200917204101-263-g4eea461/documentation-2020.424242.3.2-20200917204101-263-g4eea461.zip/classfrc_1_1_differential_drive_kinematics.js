var classfrc_1_1_differential_drive_kinematics =
[
    [ "DifferentialDriveKinematics", "classfrc_1_1_differential_drive_kinematics.html#ab66a093dd7521eded273cb45cae32260", null ],
    [ "ToChassisSpeeds", "classfrc_1_1_differential_drive_kinematics.html#a12f5140b2c56473e2594e5bbd6138980", null ],
    [ "ToWheelSpeeds", "classfrc_1_1_differential_drive_kinematics.html#aad1ec6f260c93d1efff03f285f9308f7", null ],
    [ "trackWidth", "classfrc_1_1_differential_drive_kinematics.html#a10b5f836f3e62bd397be3f426e4a54d3", null ]
];
var classfrc_1_1sim_1_1_battery_sim =
[
    [ "Calculate", "classfrc_1_1sim_1_1_battery_sim.html#a86bdca5dfc8818706f5405aa616e6f82", null ],
    [ "Calculate", "classfrc_1_1sim_1_1_battery_sim.html#a7d24f778a66abea773d7e67947a788bb", null ]
];
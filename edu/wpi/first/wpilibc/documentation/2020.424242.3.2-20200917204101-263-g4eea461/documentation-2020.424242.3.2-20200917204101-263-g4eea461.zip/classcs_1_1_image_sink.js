var classcs_1_1_image_sink =
[
    [ "ImageSink", "classcs_1_1_image_sink.html#a751302b02aff4b53ec7341dc0546618d", null ],
    [ "GetError", "classcs_1_1_image_sink.html#a20c4a4b9f8d6e7102a8ee8e636a4711b", null ],
    [ "SetDescription", "classcs_1_1_image_sink.html#a025b70589634f54ffe76d5cf205e569a", null ],
    [ "SetEnabled", "classcs_1_1_image_sink.html#a038144e490235aa8e02f95bdbc3667e5", null ]
];
var classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_gearing =
[
    [ "k10p71", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_gearing.html#a1dfcf86f8d79f4972f7e9ff79858baad", null ],
    [ "k12p75", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_gearing.html#ae4903a4f3b19954decc468f39708ae79", null ],
    [ "k5p95", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_gearing.html#a56e4520f91a0aae5e4d1cf44a80193e7", null ],
    [ "k7p31", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_gearing.html#a946d011d38fcc0e37bb9070d907c96f4", null ],
    [ "k8p45", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_gearing.html#a76d64f3223825ed195dc191e186bb767", null ]
];
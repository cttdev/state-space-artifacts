var classdrake_1_1never__destroyed =
[
    [ "never_destroyed", "classdrake_1_1never__destroyed.html#a5a491c3d4e9d0b32cc4fb044efa44ecb", null ],
    [ "~never_destroyed", "classdrake_1_1never__destroyed.html#a51021f5918c56e9131c3764987a5b531", null ],
    [ "access", "classdrake_1_1never__destroyed.html#a05c0068672569966889effd8d1246bbf", null ],
    [ "access", "classdrake_1_1never__destroyed.html#a8e10bff3ffba0f5f2e515c1ace31b8e5", null ]
];
var classcs_1_1_video_property =
[
    [ "Kind", "classcs_1_1_video_property.html#a7c48bc795a9e2e6a9e2b22ec543c50c1", [
      [ "kNone", "classcs_1_1_video_property.html#a7c48bc795a9e2e6a9e2b22ec543c50c1aa9ec4c3664d4dfbdb20af1a3ddc7c6fa", null ],
      [ "kBoolean", "classcs_1_1_video_property.html#a7c48bc795a9e2e6a9e2b22ec543c50c1a3d78268e24ac5ace2c369140cd338f0d", null ],
      [ "kInteger", "classcs_1_1_video_property.html#a7c48bc795a9e2e6a9e2b22ec543c50c1a310a54ab27fd355ef62640ccff9d2ab7", null ],
      [ "kString", "classcs_1_1_video_property.html#a7c48bc795a9e2e6a9e2b22ec543c50c1a167dbac057b380e54ea7f3c2f7414e07", null ],
      [ "kEnum", "classcs_1_1_video_property.html#a7c48bc795a9e2e6a9e2b22ec543c50c1a318d3bf8a63b515c034888085b03bdeb", null ]
    ] ],
    [ "VideoProperty", "classcs_1_1_video_property.html#aebc0147a974d855e85931fb4677bb8d2", null ],
    [ "Get", "classcs_1_1_video_property.html#a20ecbd770128eef6e8520e449323527c", null ],
    [ "GetChoices", "classcs_1_1_video_property.html#aadd3fafb5393cc4ce56b3c63a166a2b3", null ],
    [ "GetDefault", "classcs_1_1_video_property.html#a7806deb4394effb322a04fcdb7b52f69", null ],
    [ "GetKind", "classcs_1_1_video_property.html#ad73ce019c97360687439f30fd5fd9b5c", null ],
    [ "GetLastStatus", "classcs_1_1_video_property.html#a963177cf2f3b1122d5c36a18796d1afb", null ],
    [ "GetMax", "classcs_1_1_video_property.html#afac97aaea5471f65d37289278093ef71", null ],
    [ "GetMin", "classcs_1_1_video_property.html#a00b3de0e410fe586d5a85f37947bfe62", null ],
    [ "GetName", "classcs_1_1_video_property.html#a4fd880af1d19c8f4af938ccec2b4ce7d", null ],
    [ "GetStep", "classcs_1_1_video_property.html#acf8e8a83ab8140041c2b49a2c214d131", null ],
    [ "GetString", "classcs_1_1_video_property.html#af40883a055568e0ad2b4cb31aa429451", null ],
    [ "GetString", "classcs_1_1_video_property.html#ad0b1b67b01780ccec66bca3ea07e4ccf", null ],
    [ "IsBoolean", "classcs_1_1_video_property.html#aaa0e29c8697d50e86e1c8b19bfa16842", null ],
    [ "IsEnum", "classcs_1_1_video_property.html#a4e315edafc8a4ffd72fa770d0069e164", null ],
    [ "IsInteger", "classcs_1_1_video_property.html#a310e3ae0df6f258e8220f958ee5418a6", null ],
    [ "IsString", "classcs_1_1_video_property.html#adf30fd81dd7df220ee61f1cbbc3a60a8", null ],
    [ "operator bool", "classcs_1_1_video_property.html#ad37e001221bf0311c7bebd82e09fedbd", null ],
    [ "Set", "classcs_1_1_video_property.html#aa04937e7ca5df1740b49e938334521de", null ],
    [ "SetString", "classcs_1_1_video_property.html#aa880d95de0c837819cfb58231826147e", null ],
    [ "ImageSource", "classcs_1_1_video_property.html#af4903c0d51a7c5de111ff9ff4914137f", null ],
    [ "VideoEvent", "classcs_1_1_video_property.html#ace63f20158a3037e0316962613f821f2", null ],
    [ "VideoSink", "classcs_1_1_video_property.html#a761a1a07505f1d3f9776b46815d4ef0d", null ],
    [ "VideoSource", "classcs_1_1_video_property.html#ad165dabf73053c60bb1c4386ea0a3387", null ]
];
var classfrc_1_1sim_1_1_generic_h_i_d_sim =
[
    [ "GenericHIDSim", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a272e6ee6b6ba09ec534a165ee9fcfc98", null ],
    [ "GenericHIDSim", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a4c10aeb5c1b412c75678677506a103f4", null ],
    [ "GetOutput", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#aa2e916efcb10e5d1e2859dcdc35bbbce", null ],
    [ "GetOutputs", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a283343bea3115f232ff1b69b71c251f5", null ],
    [ "GetRumble", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#ac48ac7ce0500116e9a415940fdc0e9eb", null ],
    [ "NotifyNewData", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a3f3ee4d20b83f5e5de49184a011cfaae", null ],
    [ "SetAxisCount", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a0147de7d6c4326289f5913fba548d122", null ],
    [ "SetAxisType", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#af86e40e044d1aecbaf49302821090eaa", null ],
    [ "SetButtonCount", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a8d25b0bf317e2b19fcd2572f4e7db517", null ],
    [ "SetName", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#ad603735c9e4be9a88ac432cff14f77e3", null ],
    [ "SetPOV", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a634466b5f897592daf2724e3ed2adda0", null ],
    [ "SetPOV", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a5174e9cf7eef0a7475237f58e8193930", null ],
    [ "SetPOVCount", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#abd1bf586dcd6cd0c72e791211f07fad0", null ],
    [ "SetRawAxis", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#aaf8bd426f1931bda1daa5c2feb14c9f7", null ],
    [ "SetRawButton", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a42deac0815dc2fb3967c636c0695349c", null ],
    [ "SetType", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#a8d568347fc2e9ee472ad20872ffb9cad", null ],
    [ "m_port", "classfrc_1_1sim_1_1_generic_h_i_d_sim.html#af0d24f353d1890d03ff68ae1f71330ae", null ]
];
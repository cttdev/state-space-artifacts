var classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_wheel_size =
[
    [ "kEightInch", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_wheel_size.html#afd149c7cc5b01bc87d34cf13ab6286ed", null ],
    [ "kSixInch", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_wheel_size.html#acda7c686214e5a203f29dba706fc86db", null ],
    [ "kTenInch", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_wheel_size.html#a7aca7169c52995b7d1ba1cdf5be09761", null ]
];
var classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_motor =
[
    [ "DualCIMPerSide", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_motor.html#ab0ff634b39051e7a55ae7ca55d9aee96", null ],
    [ "DualMiniCIMPerSide", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_motor.html#ab760c34cb2f0c26d2fab22554afa2730", null ],
    [ "SingleCIMPerSide", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_motor.html#aac8a1db6575a2ee04b368f434a6114d1", null ],
    [ "SingleMiniCIMPerSide", "classfrc_1_1sim_1_1_differential_drivetrain_sim_1_1_kitbot_motor.html#a9c30611f3d11df00bf283da66b02ec36", null ]
];
var classfrc_1_1sim_1_1_analog_encoder_sim =
[
    [ "AnalogEncoderSim", "classfrc_1_1sim_1_1_analog_encoder_sim.html#af9c8594dc4909948adcd5d3e9227a854", null ],
    [ "GetPosition", "classfrc_1_1sim_1_1_analog_encoder_sim.html#a693e483b6eade4b532e249d02840e8db", null ],
    [ "GetTurns", "classfrc_1_1sim_1_1_analog_encoder_sim.html#af22af8b3f3bfa02fe822943e8440c0e7", null ],
    [ "SetPosition", "classfrc_1_1sim_1_1_analog_encoder_sim.html#aa1c66b778ed3106439a18d281b8efe19", null ],
    [ "SetTurns", "classfrc_1_1sim_1_1_analog_encoder_sim.html#ab0941a8985e717ef4bbf785f503b6c97", null ]
];
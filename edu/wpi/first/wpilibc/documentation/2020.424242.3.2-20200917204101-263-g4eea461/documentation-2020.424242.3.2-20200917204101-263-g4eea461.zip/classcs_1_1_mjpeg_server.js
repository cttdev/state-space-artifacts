var classcs_1_1_mjpeg_server =
[
    [ "MjpegServer", "classcs_1_1_mjpeg_server.html#a885b674ead2793e02edbc84b0b2b3bbe", null ],
    [ "MjpegServer", "classcs_1_1_mjpeg_server.html#aa44311b1495b3081b53869030737d540", null ],
    [ "MjpegServer", "classcs_1_1_mjpeg_server.html#a37e16906eaac5e0909a1c77bb009e57d", null ],
    [ "GetListenAddress", "classcs_1_1_mjpeg_server.html#a8b2294c7a8710e8ad8904454cee2ccf8", null ],
    [ "GetPort", "classcs_1_1_mjpeg_server.html#ac4fea0e212aec552dd945115daa958e1", null ],
    [ "SetCompression", "classcs_1_1_mjpeg_server.html#aba90c33f4620542ad79cd65dda0379cb", null ],
    [ "SetDefaultCompression", "classcs_1_1_mjpeg_server.html#ab2f5e20ec58984c75ab74d6809d2bd58", null ],
    [ "SetFPS", "classcs_1_1_mjpeg_server.html#a4a74f6e096a8406b8ef7ad35785edaeb", null ],
    [ "SetResolution", "classcs_1_1_mjpeg_server.html#a631312b6156c09c9c5d5efbb780c51c5", null ]
];
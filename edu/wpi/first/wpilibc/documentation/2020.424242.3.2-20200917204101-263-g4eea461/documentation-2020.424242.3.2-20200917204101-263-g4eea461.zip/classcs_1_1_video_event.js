var classcs_1_1_video_event =
[
    [ "GetProperty", "classcs_1_1_video_event.html#a2936f172ffd0f7480b9f2c452470472c", null ],
    [ "GetSink", "classcs_1_1_video_event.html#a198626fd2c9df57943841209c615bd2e", null ],
    [ "GetSource", "classcs_1_1_video_event.html#a79d2e566912578d64c7853d995e4dbf2", null ]
];
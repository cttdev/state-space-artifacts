var classfrc_1_1_elevator_feedforward =
[
    [ "Acceleration", "classfrc_1_1_elevator_feedforward.html#abcf0f05092f91475ef7963f323289ffe", null ],
    [ "ka_unit", "classfrc_1_1_elevator_feedforward.html#a90f21d5596abd4f4530c03bea8e20ada", null ],
    [ "kv_unit", "classfrc_1_1_elevator_feedforward.html#acf276a5c244c84580a670a9bee1df4a0", null ],
    [ "Velocity", "classfrc_1_1_elevator_feedforward.html#a3aacfc1f278b18b6db940a4e2b927554", null ],
    [ "ElevatorFeedforward", "classfrc_1_1_elevator_feedforward.html#afcd91ca93ccb0b7ffc09d1f0425f9be6", null ],
    [ "ElevatorFeedforward", "classfrc_1_1_elevator_feedforward.html#a3c3ea34e0f20d0b58ce0fa73cb92106f", null ],
    [ "Calculate", "classfrc_1_1_elevator_feedforward.html#a5eef769a83b9b8dbda7b605444f03d9c", null ],
    [ "MaxAchievableAcceleration", "classfrc_1_1_elevator_feedforward.html#a9ce97a7c88a7cdb32ad53bcbf2c59aef", null ],
    [ "MaxAchievableVelocity", "classfrc_1_1_elevator_feedforward.html#a73d47e21726e5018c8af98aab1a8029c", null ],
    [ "MinAchievableAcceleration", "classfrc_1_1_elevator_feedforward.html#aef0703e075b22b2196c67adf91cf6896", null ],
    [ "MinAchievableVelocity", "classfrc_1_1_elevator_feedforward.html#a4ec4bcf9525053c6921af2f42822e09a", null ],
    [ "kA", "classfrc_1_1_elevator_feedforward.html#a3f6ca39b02dc06ea6009cf905ac96a7a", null ],
    [ "kG", "classfrc_1_1_elevator_feedforward.html#ae39e57aaa304d49985853353c39c6380", null ],
    [ "kS", "classfrc_1_1_elevator_feedforward.html#a5f612929d669d64809f670557b194a66", null ],
    [ "kV", "classfrc_1_1_elevator_feedforward.html#aba5ec71554befafc8dd9c8560eecb463", null ]
];
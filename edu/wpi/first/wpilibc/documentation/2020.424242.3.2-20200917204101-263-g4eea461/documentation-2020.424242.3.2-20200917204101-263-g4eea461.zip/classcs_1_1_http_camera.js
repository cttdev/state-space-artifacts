var classcs_1_1_http_camera =
[
    [ "HttpCameraKind", "classcs_1_1_http_camera.html#a83a6f6ff2f5c00b49faf6488aab9321d", [
      [ "kUnknown", "classcs_1_1_http_camera.html#a83a6f6ff2f5c00b49faf6488aab9321dad046dd82c51480b98656cf5077835de1", null ],
      [ "kMJPGStreamer", "classcs_1_1_http_camera.html#a83a6f6ff2f5c00b49faf6488aab9321da21eac708647501c1961d597898838582", null ],
      [ "kCSCore", "classcs_1_1_http_camera.html#a83a6f6ff2f5c00b49faf6488aab9321dabfc70e68ff7f22d8fca0ab3e6e020f4e", null ],
      [ "kAxis", "classcs_1_1_http_camera.html#a83a6f6ff2f5c00b49faf6488aab9321dacff84bf2f22913f78ea13b4c2079ff92", null ]
    ] ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#a45c0dcc17442aef0bb0dfde06dea870b", null ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#ae6b960450f072ed81134081faaf6b1aa", null ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#ad9f3316e59ef5b107934a92b426160a6", null ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#ad1353ac1dd367a2cb4ec4734501657c9", null ],
    [ "HttpCamera", "classcs_1_1_http_camera.html#a9b8a43ab418634f6f1fb965aa7be8e95", null ],
    [ "GetHttpCameraKind", "classcs_1_1_http_camera.html#abc4132d35d5405087c14a582ac13a392", null ],
    [ "GetUrls", "classcs_1_1_http_camera.html#a2098e86539dc7882bbf493540b542d65", null ],
    [ "SetUrls", "classcs_1_1_http_camera.html#a4b048a5e03c69c86836b8aba70eba501", null ],
    [ "SetUrls", "classcs_1_1_http_camera.html#ab762fd8fd190f92155c52f95e37558ba", null ]
];
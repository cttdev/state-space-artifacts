var classfrc_1_1_accelerometer =
[
    [ "Range", "classfrc_1_1_accelerometer.html#a701c1a0fb5a5c3f9bfd07991ff893f93", [
      [ "kRange_2G", "classfrc_1_1_accelerometer.html#a701c1a0fb5a5c3f9bfd07991ff893f93a1ec2542e09c9856285d3c28cab555e53", null ],
      [ "kRange_4G", "classfrc_1_1_accelerometer.html#a701c1a0fb5a5c3f9bfd07991ff893f93a2e88fbb567f568addc77848fab785b51", null ],
      [ "kRange_8G", "classfrc_1_1_accelerometer.html#a701c1a0fb5a5c3f9bfd07991ff893f93a6bf1ad319b8dcf3c2ba578f08eb6e8f5", null ],
      [ "kRange_16G", "classfrc_1_1_accelerometer.html#a701c1a0fb5a5c3f9bfd07991ff893f93a0a32d5949adc1ed911d79f9e83030e6f", null ]
    ] ],
    [ "Accelerometer", "classfrc_1_1_accelerometer.html#a5d391e33308914a751d30c6d56de95a3", null ],
    [ "~Accelerometer", "classfrc_1_1_accelerometer.html#ae8fb7f7abdd159e1a6ff9494c7a194c3", null ],
    [ "Accelerometer", "classfrc_1_1_accelerometer.html#a50ad40f69850546949da946d7c4e3872", null ],
    [ "GetX", "classfrc_1_1_accelerometer.html#a7159637b2f9db1906be57cf9defe0889", null ],
    [ "GetY", "classfrc_1_1_accelerometer.html#a9d5560448cccc30d853d87d22caea7f9", null ],
    [ "GetZ", "classfrc_1_1_accelerometer.html#a3f30d06f5b5971a538d4f1ecadf29ca2", null ],
    [ "operator=", "classfrc_1_1_accelerometer.html#a87d884da474172f242f2e5cdbab84b3f", null ],
    [ "SetRange", "classfrc_1_1_accelerometer.html#a5399dc4ab0ca47202fddb7e7f14c42e0", null ]
];
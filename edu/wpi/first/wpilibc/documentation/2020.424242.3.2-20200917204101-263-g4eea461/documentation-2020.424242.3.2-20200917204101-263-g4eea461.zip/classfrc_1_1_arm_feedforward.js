var classfrc_1_1_arm_feedforward =
[
    [ "Acceleration", "classfrc_1_1_arm_feedforward.html#aa25f5a29ba90ad71d891b0ddb2311788", null ],
    [ "Angle", "classfrc_1_1_arm_feedforward.html#aaabbd274e9c4278f6a95e2c2ef54f33d", null ],
    [ "ka_unit", "classfrc_1_1_arm_feedforward.html#a9d4aa1810e66a8047e60ae2744ccc5e6", null ],
    [ "kv_unit", "classfrc_1_1_arm_feedforward.html#af3000d63ab293dcaa3b60e96c764520a", null ],
    [ "Velocity", "classfrc_1_1_arm_feedforward.html#a2d7490cab277aaa464fbb150cd35d35a", null ],
    [ "ArmFeedforward", "classfrc_1_1_arm_feedforward.html#adb9e0c8ff49c94226b6af78b6d67fe73", null ],
    [ "ArmFeedforward", "classfrc_1_1_arm_feedforward.html#a6bc1f89d58d803378457cd913c3bda9e", null ],
    [ "Calculate", "classfrc_1_1_arm_feedforward.html#a432cc0b9e30ecae14a0fd38490536d1a", null ],
    [ "MaxAchievableAcceleration", "classfrc_1_1_arm_feedforward.html#a70a480d2670aae284f334fdcefb4e7a0", null ],
    [ "MaxAchievableVelocity", "classfrc_1_1_arm_feedforward.html#add9b1b24f13a55a1ee93b59bcfa4f6b1", null ],
    [ "MinAchievableAcceleration", "classfrc_1_1_arm_feedforward.html#a347e294b0522bc7c000077617620dfd2", null ],
    [ "MinAchievableVelocity", "classfrc_1_1_arm_feedforward.html#a515b864582d612eb70d0e22d2155518c", null ],
    [ "kA", "classfrc_1_1_arm_feedforward.html#a795374254536e728431d84a33c9fa5b6", null ],
    [ "kCos", "classfrc_1_1_arm_feedforward.html#a53b97319c258b15db9f2746330a744f1", null ],
    [ "kS", "classfrc_1_1_arm_feedforward.html#a5518e4828f4714fbe16ccbf6038a4aa0", null ],
    [ "kV", "classfrc_1_1_arm_feedforward.html#ab181b7ae7d58d56f3ecc77477ef30bc8", null ]
];
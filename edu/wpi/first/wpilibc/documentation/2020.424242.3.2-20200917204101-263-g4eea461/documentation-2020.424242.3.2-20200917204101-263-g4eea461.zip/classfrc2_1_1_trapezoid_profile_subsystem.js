var classfrc2_1_1_trapezoid_profile_subsystem =
[
    [ "TrapezoidProfileSubsystem", "classfrc2_1_1_trapezoid_profile_subsystem.html#a4922503f3c7afc8070f446dbaddf9d1e", null ],
    [ "Disable", "classfrc2_1_1_trapezoid_profile_subsystem.html#a2cba2c93cc80a15ab16b3d01515d6f42", null ],
    [ "Enable", "classfrc2_1_1_trapezoid_profile_subsystem.html#a6b32f020e03e8aab8fd3d29f803dce7d", null ],
    [ "Periodic", "classfrc2_1_1_trapezoid_profile_subsystem.html#a6980ed26bd28420d9bb96af5651956a5", null ],
    [ "SetGoal", "classfrc2_1_1_trapezoid_profile_subsystem.html#a34ead6cec35306f73fd978765a29be19", null ],
    [ "SetGoal", "classfrc2_1_1_trapezoid_profile_subsystem.html#a061a596cd5e7f7438223790589384716", null ],
    [ "UseState", "classfrc2_1_1_trapezoid_profile_subsystem.html#a7dd62957eebb5e17fcd37ec70134ae11", null ]
];